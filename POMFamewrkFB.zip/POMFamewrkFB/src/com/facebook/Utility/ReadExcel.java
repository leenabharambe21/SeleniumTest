package com.facebook.Utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	
	public static boolean isTestCaseRunable(String testCaseName) throws IOException
	{
	FileInputStream fs=new FileInputStream(System.getProperty("user.dir")+"\\src\\com\\facebook\\TestCasesData\\TestCasesFB.xlsx");
	XSSFWorkbook book=new XSSFWorkbook(fs);
	XSSFSheet sh= book.getSheet("Sheet1");
	System.out.println("Test1");
	//total rows
	int totRows=sh.getPhysicalNumberOfRows();

	
	//total cell
	int totCell=sh.getRow(0).getPhysicalNumberOfCells();
	System.out.println("Tst2");
	for (int i=0;i<totRows;i++)
	{
		if(sh.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(testCaseName))
		{
			if(sh.getRow(i).getCell(1).getStringCellValue().equalsIgnoreCase("Y"))
			{
				System.out.println("Test3");
				return true;
			}
		}
	}
	
	return false;
	
	}
	
	public static Object[][]  readDataFromExcel() throws IOException
	{
		FileInputStream io= new FileInputStream(System.getProperty("user.dir")+"\\src\\com\\facebook\\TestCasesData\\TestCasesFB.xlsx");
		XSSFWorkbook testBook =new XSSFWorkbook(io);
		XSSFSheet testSheet=testBook.getSheet("LoginTest");
		System.out.println("FB1");
		int totalRows=testSheet.getPhysicalNumberOfRows();
		int totalCell=testSheet.getRow(0).getPhysicalNumberOfCells();
		Object arr[][]=new Object[totalRows-1][totalCell] ;
		System.out.println("FB2");
		for(int i=1;i<totalRows;i++)
		{
			for(int j=0;j<totalCell;j++)
			{
				arr[i-1][j]=testSheet.getRow(i).getCell(j);
				
			}
		}
		System.out.println("FB4");
		return arr;
	}
	
	

}
