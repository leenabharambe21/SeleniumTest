package com.facebook.Tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.facebook.Pages.LoginPage;
import com.facebook.Utility.ReadExcel;

public class LoginTest {

	@Test(dataProvider="getLoginData")
	public void loginTestCase(String userName,String password) throws IOException
	{
		System.out.println("Hello2");
		if(ReadExcel.isTestCaseRunable("LoginTest"))
		{
		LoginPage lp=new LoginPage();
		System.out.println("Hello");
		Assert.assertTrue(lp.doLogin( userName, password));
		System.out.println("Hi");
		}
		
	}
	
	@DataProvider
	public Object[][] getLoginData() throws IOException
	{System.out.println("Hello1");
	Object arr[][]  =ReadExcel.readDataFromExcel();
	String username =(String) arr[0][0];
	String password  =(String) arr[0][0];
	System.out.println("username,passwrd" +username + password);
	return arr;
	  //return (ReadExcel.readDataFromExcel());	
	  
	}
	

	

}
