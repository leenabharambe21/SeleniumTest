package com.facebook.Pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.facebook.MPage.MasterPage;
import com.facebook.Utility.ReadExcel;

public class LoginPage  extends MasterPage
{
	public LoginPage() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean doLogin(String userName,String password)
	{
		/*sendData("userName_txtBox","chshweta91@gmail.com");
		sendData("password_txtBox","Pune@123");*/
		//click("login_button");
		
		sendData("userName_txtBox",userName);
		sendData("password_txtBox",password);
		
		return isLinkPresent("home_link");
		
		
	
	//driver.findElement(By.xpath("//input[@id='email']")).sendKeys("chshweta91@gmail.com");
	//driver.findElement(By.xpath("//input[@id='pass']")).sendKeys("Pune@123");
	//driver.findElement(By.xpath("//input[@value='Log In']")).click();
	}
	
	
	
	
	
	

	
	
}


