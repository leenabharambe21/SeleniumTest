package com.facebook.MPage;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MasterPage {
	
	 public WebDriver driver;
	 public Properties config;
	 public Properties or;
	public MasterPage() throws IOException
	{
		// Read Config properties File
		FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"\\src\\com\\facebook\\config\\Config.properties");
		 config=new Properties();
		config.load(ip);
		
		//Read Object Repository properties files
		ip=new FileInputStream(System.getProperty("user.dir")+"\\src\\com\\facebook\\config\\ObjectRepository.properties");
		 or=new Properties();
		or.load(ip);
		   
		   
		if(config.getProperty("browserName").equalsIgnoreCase("Firefox"))
		{
			driver = new FirefoxDriver();
		}
		else if(config.getProperty("browserName").equalsIgnoreCase("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"src\\Drivers\\chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(config.getProperty("browserName").equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"src\\Drivers\\IEDriverServer.exe");
		}
		 
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get(config.getProperty("url"));
		//driver.get("http://www.facebook.com");
	}
	
	public  void sendData(String xpathKey,String value)
	{
		driver.findElement(By.xpath(or.getProperty(xpathKey))).sendKeys(value);
	}
	public void click(String xpathKey)
	{
		driver.findElement(By.xpath(or.getProperty(xpathKey))).click();
	}
	public boolean isLinkPresent(String xpathKey)
	{
		try
		{
			driver.findElement(By.xpath(or.getProperty(xpathKey)));
			return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}
		
		
	}


